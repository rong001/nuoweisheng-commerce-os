/** Commerce state engine. Monetary values are integer CNY cents; fees are basis points. */
export type Scenario = 'daily' | 'growth' | 'profit';
export type Role = 'operator' | 'approver' | 'viewer';
export type Product = { id: string; name: string; spec: string; category: string; cost: number; shipping: number; stock: number; daily: number; supplierId: string };
export type Listing = { id: string; productId: string; channel: string; price: number; competitor: number; fee: number; listed: boolean; version: number; content?: string };
export type Order = { id: string; productId: string; channel: string; customerId: string; qty: number; unitPrice: number; cost: number; shipping: number; fee: number; status: 'pending' | 'shortage' | 'shipped' | 'cancelled'; createdAt: string; tracking?: string };
export type Task = { id: string; type: 'price' | 'purchase' | 'listing' | 'content'; productId: string; listingId?: string; title: string; before?: number | string; after?: number | string; qty?: number; status: 'pending' | 'approved' | 'executed' | 'rejected' | 'rolledback'; creator: Role | 'system'; createdAt: string; version?: number; executedVersion?: number; cost?: number; shipping?: number; fee?: number; supplierId?: string; reason?: string; approver?: Role };
export type Purchase = { id: string; productId: string; supplierId: string; qty: number; received: number; status: 'transit' | 'partial' | 'received'; createdAt: string; taskId?: string };
export type Aftersale = { id: string; orderId: string; type: 'refund' | 'return'; qty: number; amount: number; status: 'pending' | 'approved' | 'received' | 'completed' | 'rejected'; createdAt: string; reason: string; creator: Role | 'system'; returnedAt?: string; completedAt?: string };
export type Customer = { id: string; name: string; tier: string; tags: string[]; note: string };
export type Supplier = { id: string; name: string; leadDays: number; contact: string };
export type Audit = { id: string; time: string; action: string; object: string; before: string; after: string; actor: string };
export type Rule = { id: string; name: string; type: 'price' | 'stock' | 'listing'; enabled: boolean; threshold: number; runs: number; lastRun?: string };
export type State = { schemaVersion: 2; scenario: Scenario; role: Role; products: Product[]; listings: Listing[]; orders: Order[]; tasks: Task[]; purchases: Purchase[]; aftersales: Aftersale[]; customers: Customer[]; suppliers: Supplier[]; logs: Audit[]; rules: Rule[]; revision: number; updatedAt: string };
export type Action =
  | { type: 'set_role'; role: Role }
  | { type: 'suggest_price'; listingId: string; price: number; reason?: string }
  | { type: 'suggest_purchase'; productId: string; qty: number; supplierId?: string; reason?: string }
  | { type: 'suggest_listing'; listingId: string; listed?: boolean; reason?: string }
  | { type: 'suggest_content'; listingId: string; content: string }
  | { type: 'approve' | 'reject' | 'execute' | 'rollback'; id: string }
  | { type: 'ship' | 'cancel' | 'reserve'; id: string }
  | { type: 'receive'; id: string; qty?: number }
  | { type: 'aftersale_create'; id: string; kind: 'refund' | 'return'; qty: number; amount?: number; reason?: string }
  | { type: 'aftersale_approve' | 'aftersale_reject' | 'aftersale_receive' | 'aftersale_complete'; id: string }
  | { type: 'customer_update'; id: string; tags?: string[]; note?: string; tier?: string }
  | { type: 'supplier_update'; id: string; leadDays?: number; contact?: string }
  | { type: 'rule_update'; id: string; enabled?: boolean; threshold?: number }
  | { type: 'run_rules'; id?: string };

export const channels = ['天猫', '京东', '拼多多', '美团', '私域'] as const;
export const scenarioNames: Record<Scenario, string> = { daily: '稳态经营', growth: '增长备货', profit: '利润优化' };
export const roleNames: Record<Role | 'system', string> = { operator: '运营专员', approver: '业务负责人', viewer: '只读成员', system: '自动化规则' };
export const statusNames: Record<string, string> = { pending: '待处理', approved: '已批准', executed: '已执行', rejected: '已驳回', rolledback: '已回滚', shortage: '待补货', shipped: '已发货', cancelled: '已取消', transit: '在途', partial: '部分入库', received: '已入库', completed: '已完成' };
export const money = (cents: number) => new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(cents / 100);
export const reserved = (s: State, product: Product | string) => s.orders.filter(o => o.productId === (typeof product === 'string' ? product : product.id) && o.status === 'pending').reduce((n, o) => n + o.qty, 0);
export const available = (s: State, product: Product | string) => { const p = typeof product === 'string' ? s.products.find(x => x.id === product) : product; return p ? p.stock - reserved(s, p) : 0; };
export const inTransit = (s: State, product: Product | string) => s.purchases.filter(p => p.productId === (typeof product === 'string' ? product : product.id)).reduce((n, p) => n + p.qty - p.received, 0);
export const coverage = (s: State, p: Product) => p.daily > 0 ? available(s, p) / p.daily : Infinity;
export const suggestedQty = (s: State, p: Product) => Math.max(0, Math.ceil(p.daily * ((s.suppliers.find(x => x.id === p.supplierId)?.leadDays ?? 7) + 3) - available(s, p) - inTransit(s, p)));
export const channelFee = (amount: number, fee: number) => Math.round(amount * fee / 10000);
export const margin = (p: Product, price: number, fee = 800) => price > 0 ? Math.round((price - p.cost - p.shipping - channelFee(price, fee)) / price * 1000) / 10 : 0;
export const priceFloor = (p: Product, fee = 800) => Math.ceil((p.cost + p.shipping) / (0.8 - fee / 10000));
export const orderAmount = (o: Order) => o.qty * o.unitPrice;
const now = () => new Date().toISOString();
const uid = (prefix: string) => `${prefix}-${globalThis.crypto.randomUUID().slice(0, 8).toUpperCase()}`;
const integer = (v: number, min: number, max: number, label: string) => { if (!Number.isSafeInteger(v) || v < min || v > max) throw new Error(`${label}须为 ${min}–${max} 的整数`); };
const productOf = (s: State, id: string) => { const p = s.products.find(x => x.id === id); if (!p) throw new Error('商品不存在'); return p; };
const listingOf = (s: State, id: string) => { const l = s.listings.find(x => x.id === id); if (!l) throw new Error('渠道商品不存在'); return l; };
const audit = (s: State, action: string, object: string, before: unknown, after: unknown) => { s.logs.unshift({ id: uid('EV'), time: now(), actor: roleNames[s.role], action, object, before: String(before ?? '—'), after: String(after ?? '—') }); s.logs = s.logs.slice(0, 1000); };
const requireApprover = (s: State) => { if (s.role !== 'approver') throw new Error('此操作需要业务负责人权限'); };
const validatePrice = (p: Product, l: Listing, price: number) => { integer(price, 1, 10000000, '售价（分）'); if (price - p.cost - p.shipping - channelFee(price, l.fee) < price * .2) throw new Error(`贡献利润率不能低于 20%，当前最低售价为 ${money(priceFloor(p, l.fee))}`); };
const openTasks = (s: State, type: Task['type'], productId: string, listingId?: string) => s.tasks.some(t => t.type === type && t.productId === productId && t.listingId === listingId && (t.status === 'pending' || t.status === 'approved'));
function addTask(s: State, task: Omit<Task, 'id' | 'status' | 'creator' | 'createdAt'>, creator: Task['creator'] = s.role): Task {
  if (openTasks(s, task.type, task.productId, task.listingId)) throw new Error('已有同类待处理任务，请先完成或驳回');
  const t: Task = { ...task, id: uid('AP'), status: 'pending', creator, createdAt: now() };
  s.tasks.unshift(t); audit(s, '提交审批', t.id, '未提交', t.title); return t;
}

export function createState(scenario: Scenario = 'daily'): State {
  if (!['daily', 'growth', 'profit'].includes(scenario)) throw new Error('业务空间不存在');
  const count = scenario === 'growth' ? 32 : 24;
  const total = scenario === 'growth' ? 96 : scenario === 'profit' ? 64 : 48;
  const base = Date.parse('2026-09-27T10:00:00+08:00');
  const at = (hours: number) => new Date(base - hours * 3600000).toISOString();
  const names = [
    ['柔棉洁面巾', '3 包 / 组', '个人护理', 1200, 3500], ['便携清洁湿巾', '10 包 / 组', '家庭清洁', 950, 2990],
    ['一次性护理手套', '100 只 / 盒', '日常防护', 2200, 5900], ['家庭护理组合装', '6 件 / 盒', '个人护理', 7800, 13900],
    ['一次性防护口罩', '50 只 / 盒', '日常防护', 1600, 4290], ['旅行收纳护理包', '1 套 / 袋', '出行护理', 2900, 7900],
    ['日常清洁棉片', '80 片 / 盒', '家庭清洁', 580, 1990], ['便携防护套装', '3 件 / 套', '出行护理', 2300, 5900],
  ] as const;
  const suppliers: Supplier[] = [
    { id: 'SUP-01', name: '华南日用供应链', leadDays: 5, contact: '林经理' },
    { id: 'SUP-02', name: '惠州清洁用品工厂', leadDays: 7, contact: '陈经理' },
    { id: 'SUP-03', name: '东莞护理用品中心', leadDays: 4, contact: '周经理' },
    { id: 'SUP-04', name: '长三角包装集采', leadDays: 6, contact: '张经理' },
  ];
  const products: Product[] = Array.from({ length: count }, (_, i) => {
    const b = names[i % 8], variant = Math.floor(i / 8), growth = scenario === 'growth' ? 1.75 : 1;
    return { id: `NW-${1001 + i}`, name: `${b[0]}${variant ? ['',' · 加量装',' · 家庭装',' · 商用装'][variant] : ''}`, spec: b[1], category: b[2], cost: Math.round(b[3] * (1 + variant * .15)), shipping: i % 8 === 3 ? 600 : 300, stock: i < (scenario === 'growth' ? 6 : 3) ? 8 + i * 4 : 150 + (i * 47 % 670), daily: Math.round((8 + i * 7 % 36) * growth), supplierId: suppliers[i % 4].id };
  });
  const listings: Listing[] = products.flatMap((p, i) => channels.map((channel, ci) => {
    const b = names[i % 8], price = Math.round((b[4] * (1 + Math.floor(i / 8) * .15) + ci * 100) / 10) * 10;
    return { id: `CH-${i + 1}-${ci + 1}`, productId: p.id, channel, price, competitor: Math.max(100, price - (scenario === 'profit' ? 300 + i % 3 * 500 : 100 + i % 3 * 100)), fee: [600, 800, 500, 1000, 100][ci], listed: i < count - 3 || ci < 2, version: 1, content: `${p.name}，${p.spec}。适用于日常使用，包装规格清晰，按需选购。` };
  }));
  const customers: Customer[] = Array.from({ length: scenario === 'growth' ? 32 : 24 }, (_, i) => ({ id: `C-${String(i + 1).padStart(4, '0')}`, name: `${['林','陈','王','刘','李','周','黄','吴'][i % 8]}${['女士','先生','同学'][Math.floor(i / 8) % 3]}`, tier: i % 5 === 0 ? '高价值' : i % 3 === 0 ? '复购客户' : '普通客户', tags: i % 5 === 0 ? ['高频复购','重视包装'] : i % 3 === 0 ? ['复购客户'] : ['首次购买'], note: i % 5 === 0 ? '关注补货提醒，优先确认配送时间。' : '' }));
  const s: State = { schemaVersion: 2, scenario, role: 'operator', products, listings, orders: [], tasks: [], purchases: [], aftersales: [], customers, suppliers, logs: [], rules: [
    { id: 'RULE-PRICE', name: '竞品价差监测', type: 'price', enabled: true, threshold: 3, runs: scenario === 'profit' ? 28 : 12 },
    { id: 'RULE-STOCK', name: '库存覆盖预警', type: 'stock', enabled: true, threshold: 7, runs: scenario === 'growth' ? 36 : 24 },
    { id: 'RULE-LIST', name: '渠道上架检查', type: 'listing', enabled: false, threshold: 1, runs: 4 },
  ], revision: 1, updatedAt: at(0) };
  for (let i = 0; i < total; i++) {
    const p = products[i % count], ci = i % 5, listing = listings.find(l => l.productId === p.id && l.channel === channels[ci])!;
    const qty = i === 0 || i === 1 ? 30 + i * 10 : 1 + i % 5;
    const status: Order['status'] = i < Math.floor(total * .34) ? (available(s, p) >= qty ? 'pending' : 'shortage') : i % 17 === 0 ? 'cancelled' : 'shipped';
    s.orders.push({ id: `NW${scenario === 'daily' ? '26' : scenario === 'growth' ? '27' : '28'}0927${String(i + 1).padStart(4, '0')}`, productId: p.id, channel: channels[ci], customerId: customers[i % customers.length].id, qty, unitPrice: listing.price, cost: p.cost, shipping: p.shipping, fee: listing.fee, status, createdAt: at(Math.floor(i * 144 / total)), ...(status === 'shipped' ? { tracking: `SF${2609000000 + i}` } : {}) });
  }
  s.purchases = products.slice(0, scenario === 'growth' ? 4 : 2).map((p, i) => ({ id: `PO-2609${String(i + 1).padStart(3,'0')}`, productId: p.id, supplierId: p.supplierId, qty: 100 + i * 50, received: i === 1 ? 20 : 0, status: i === 1 ? 'partial' : 'transit', createdAt: at(24 + i * 4) }));
  // Partial historical receipts are already included in physical stock.
  s.purchases.filter(p => p.received).forEach(po => { productOf(s, po.productId).stock += po.received; });
  const priceCandidates = listings.filter(l => l.channel === '京东' && l.listed && margin(productOf(s, l.productId), l.competitor, l.fee) >= 20).slice(0, 3);
  priceCandidates.forEach((l, i) => { const p = productOf(s, l.productId); s.tasks.push({ id: `AP-PRICE-0${i+1}`, type: 'price', productId: p.id, listingId: l.id, title: `${p.name} · ${l.channel}调价`, before: l.price, after: l.competitor, status: i === 2 ? 'approved' : 'pending', creator: 'operator', ...(i === 2 ? { approver: 'approver' as Role } : {}), createdAt: at(2 + i), version: l.version, cost: p.cost, shipping: p.shipping, fee: l.fee, reason: '竞品价差达到监测阈值，建议在利润底线内调整。' }); });
  products.slice(4, scenario === 'growth' ? 8 : 6).forEach((p, i) => s.tasks.push({ id: `AP-BUY-0${i+1}`, type: 'purchase', productId: p.id, supplierId: p.supplierId, title: `${p.name} · 采购补货`, qty: Math.max(50, suggestedQty(s, p)), status: 'pending', creator: 'operator', createdAt: at(4 + i), reason: '按交期与安全库存准备补货。' }));
  const contentListing = listings.find(l => !l.listed)!;
  s.tasks.push({ id: 'AP-CONTENT-01', type: 'content', productId: contentListing.productId, listingId: contentListing.id, title: `${productOf(s, contentListing.productId).name} · 渠道文案`, before: contentListing.content, after: `${productOf(s, contentListing.productId).name}，便携易收纳，适合家庭日常与出行使用。请依照商品说明使用与保存。`, status: 'pending', creator: 'operator', createdAt: at(1), version: contentListing.version });
  if (scenario === 'profit') {
    listings.filter(l => l.channel === '天猫').slice(8, 10).forEach((l, i) => { const p = productOf(s, l.productId), before = l.price; l.price += 200; l.version = 2; s.tasks.push({ id: `AP-DONE-0${i+1}`, type: 'price', productId: p.id, listingId: l.id, title: `${p.name} · 天猫调价`, before, after: l.price, status: 'executed', creator: 'operator', approver: 'approver', createdAt: at(12+i), version: 1, executedVersion: 2, cost: p.cost, shipping: p.shipping, fee: l.fee, reason: '完成价格策略调整。' }); });
  }
  const sold = s.orders.filter(o => o.status === 'shipped');
  for (let i = 0; i < (scenario === 'profit' ? 5 : 3); i++) {
    const o = sold[i], completed = i === 2, received = i === 3, kind = i === 0 || i === 3 ? 'return' : 'refund';
    s.aftersales.push({ id: `AS-260900${i+1}`, orderId: o.id, type: kind, qty: 1, amount: o.unitPrice, status: completed ? 'completed' : received ? 'received' : i === 1 ? 'approved' : 'pending', createdAt: at(10-i), reason: ['包装破损','客户申请取消剩余使用计划','配送时效补偿','商品未拆封退回','规格选择有误'][i], creator: 'operator', ...(completed ? { completedAt: at(2) } : {}), ...(received ? { returnedAt: at(1) } : {}) });
    if (received) productOf(s, o.productId).stock++;
  }
  s.logs = [
    { id: 'EV-INITIAL-01', time: at(0), actor: '运营专员', action: '经营数据归档', object: scenarioNames[scenario], before: '待归档', after: `${products.length} 个商品、${s.orders.length} 笔订单已纳入统一账本` },
    { id: 'EV-INITIAL-02', time: at(2), actor: '业务负责人', action: '采购收货', object: s.purchases[1].id, before: '已收 0 件', after: '已收 20 件，剩余数量在途' },
    { id: 'EV-INITIAL-03', time: at(3), actor: '自动化规则', action: '库存覆盖检查', object: 'RULE-STOCK', before: '待检查', after: `${products.filter(p => coverage(s,p)<7).length} 个商品需关注库存覆盖` },
  ];
  assertState(s); return s;
}

function validateTask(s: State, task: Task) {
  const p = productOf(s, task.productId);
  if (task.type === 'price' || task.type === 'listing' || task.type === 'content') {
    const l = listingOf(s, task.listingId!);
    if (l.productId !== p.id || l.version !== task.version) throw new Error('渠道商品版本已变化，请驳回后重新提交');
    if (task.type === 'price') {
      if (p.cost !== task.cost || p.shipping !== task.shipping || l.fee !== task.fee) throw new Error('成本或费率已变化，请重新评估方案');
      validatePrice(p, l, Number(task.after));
    }
  }
  if (task.type === 'purchase') { integer(task.qty ?? 0, 1, 100000, '采购数量'); if (!s.suppliers.some(x => x.id === task.supplierId)) throw new Error('供应商不存在'); }
}

export function reduce(original: State, action: Action): State {
  const s = structuredClone(original);
  if (action.type === 'set_role') {
    if (!['operator', 'approver', 'viewer'].includes(action.role)) throw new Error('角色不存在');
    s.role = action.role; s.revision++; s.updatedAt=now(); return s;
  }
  if (s.role === 'viewer') throw new Error('当前角色仅可查看，不能修改业务数据');
  switch (action.type) {
    case 'suggest_price': {
      const l = listingOf(s, action.listingId), p = productOf(s, l.productId);
      if (!l.listed) throw new Error('请先完成渠道上架');
      validatePrice(p, l, action.price); if (action.price === l.price) throw new Error('目标价格与当前价格相同');
      addTask(s, { type: 'price', productId: p.id, listingId: l.id, title: `${p.name} · ${l.channel}调价`, before: l.price, after: action.price, version: l.version, cost: p.cost, shipping: p.shipping, fee: l.fee, reason: action.reason || `调整后贡献利润率 ${margin(p,action.price,l.fee)}%` }); break;
    }
    case 'suggest_purchase': {
      const p = productOf(s, action.productId); integer(action.qty, 1, 100000, '采购数量');
      const supplierId = action.supplierId || p.supplierId; if (!s.suppliers.some(x => x.id === supplierId)) throw new Error('供应商不存在');
      addTask(s, { type: 'purchase', productId: p.id, supplierId, title: `${p.name} · 采购补货`, qty: action.qty, reason: action.reason || `可售 ${available(s,p)} 件，在途 ${inTransit(s,p)} 件` }); break;
    }
    case 'suggest_listing': {
      const l = listingOf(s, action.listingId), p = productOf(s,l.productId), listed = action.listed ?? true;
      if (l.listed === listed) throw new Error(listed ? '该渠道商品已经上架' : '该渠道商品已经下架');
      addTask(s, { type: 'listing', productId: p.id, listingId: l.id, title: `${p.name} · ${l.channel}${listed?'上架':'下架'}`, before: Number(l.listed), after: Number(listed), version: l.version, reason: action.reason }); break;
    }
    case 'suggest_content': {
      const l = listingOf(s,action.listingId), p=productOf(s,l.productId), content=action.content.trim();
      if(content.length<10 || content.length>2000) throw new Error('商品文案须为 10–2000 字');
      if(/治愈|根治|抗癌|保证疗效|百分百|100%有效/.test(content)) throw new Error('文案包含未经证实的功效承诺，请修改后提交');
      addTask(s,{type:'content',productId:p.id,listingId:l.id,title:`${p.name} · ${l.channel}文案`,before:l.content||'',after:content,version:l.version}); break;
    }
    case 'approve': case 'reject': case 'execute': case 'rollback': {
      requireApprover(s); const t=s.tasks.find(x=>x.id===action.id); if(!t) throw new Error('审批任务不存在');
      const before=t.status;
      if(action.type==='approve'||action.type==='reject') {
        if(t.status!=='pending' && !(action.type==='reject'&&t.status==='approved')) throw new Error('当前任务状态不支持此操作');
        if(action.type==='approve') { if(t.creator===s.role) throw new Error('申请与审批需要由不同角色完成'); validateTask(s,t); t.approver=s.role; }
        t.status=action.type==='approve'?'approved':'rejected'; audit(s,action.type==='approve'?'审批通过':'审批驳回',t.id,before,t.status); break;
      }
      if(action.type==='rollback') {
        if(t.type!=='price'||t.status!=='executed') throw new Error('仅已执行的调价任务支持回滚');
        const l=listingOf(s,t.listingId!),p=productOf(s,t.productId);
        if(l.version!==t.executedVersion||l.price!==t.after) throw new Error('已有后续价格版本，不能覆盖回滚');
        validatePrice(p,l,Number(t.before)); l.price=Number(t.before);l.version++;t.status='rolledback'; audit(s,'价格回滚',l.id,money(Number(t.after)),money(l.price)); break;
      }
      if(t.status!=='approved') throw new Error('只可执行已批准任务，重复执行已被阻止');
      validateTask(s,t);
      if(t.type==='purchase') s.purchases.unshift({id:uid('PO'),productId:t.productId,supplierId:t.supplierId!,qty:t.qty!,received:0,status:'transit',createdAt:now(),taskId:t.id});
      else {
        const l=listingOf(s,t.listingId!);
        if(t.type==='price') l.price=Number(t.after);
        if(t.type==='listing') l.listed=Boolean(t.after);
        if(t.type==='content') l.content=String(t.after);
        l.version++;t.executedVersion=l.version;
      }
      t.status='executed'; audit(s,'审批任务执行',t.id,before,`${t.title}；已执行`); break;
    }
    case 'ship': case 'cancel': case 'reserve': {
      const o=s.orders.find(x=>x.id===action.id);if(!o)throw new Error('订单不存在');const p=productOf(s,o.productId),before=o.status;
      if(action.type==='ship') { if(o.status!=='pending')throw new Error('仅已占库的待发货订单可以发货'); if(p.stock<reserved(s,p))throw new Error('实物库存不足以覆盖已占用订单');p.stock-=o.qty;o.status='shipped';o.tracking=`SF${Date.now().toString().slice(-10)}`; }
      if(action.type==='cancel') {if(!['pending','shortage'].includes(o.status))throw new Error('当前订单不可取消');o.status='cancelled';}
      if(action.type==='reserve') {if(o.status!=='shortage')throw new Error('订单无需重新占库');if(available(s,p)<o.qty)throw new Error('可售库存不足，请先确认采购入库');o.status='pending';}
      audit(s,action.type==='ship'?'订单发货':action.type==='cancel'?'订单取消':'订单重新占库',o.id,before,o.status);break;
    }
    case 'receive': {
      const po=s.purchases.find(x=>x.id===action.id);if(!po||po.status==='received')throw new Error('采购单不存在或已经全部入库');const qty=action.qty??(po.qty-po.received);integer(qty,1,po.qty-po.received,'本次入库数量');
      const p=productOf(s,po.productId),before=po.received;po.received+=qty;p.stock+=qty;po.status=po.received===po.qty?'received':'partial';audit(s,'采购收货',po.id,`已收 ${before} 件`,`已收 ${po.received} 件；实物库存增加 ${qty} 件`);break;
    }
    case 'aftersale_create': {
      const o=s.orders.find(x=>x.id===action.id);if(!o||o.status!=='shipped')throw new Error('仅已发货订单可发起售后');if(!['return','refund'].includes(action.kind))throw new Error('售后类型不正确');
      const existing=s.aftersales.filter(a=>a.orderId===o.id&&a.status!=='rejected'),remainingQty=o.qty-existing.reduce((n,a)=>n+a.qty,0);integer(action.qty,1,remainingQty,'售后数量');
      const amount=action.amount??action.qty*o.unitPrice;integer(amount,1,Math.min(action.qty*o.unitPrice,orderAmount(o)-existing.reduce((n,a)=>n+a.amount,0)),'退款金额（分）');
      const a:Aftersale={id:uid('AS'),orderId:o.id,type:action.kind,qty:action.qty,amount,status:'pending',createdAt:now(),reason:(action.reason||'客户申请售后').trim().slice(0,500),creator:s.role};s.aftersales.unshift(a);audit(s,'创建售后',a.id,o.id,`${action.kind==='return'?'退货退款':'仅退款'} ${action.qty} 件，${money(amount)}`);break;
    }
    case 'aftersale_approve': case 'aftersale_reject': case 'aftersale_receive': case 'aftersale_complete': {
      const a=s.aftersales.find(x=>x.id===action.id);if(!a)throw new Error('售后单不存在');const before=a.status,o=s.orders.find(x=>x.id===a.orderId)!;
      if(action.type==='aftersale_approve'||action.type==='aftersale_reject') {
        requireApprover(s);if(a.status!=='pending')throw new Error('仅待处理售后可审核');if(action.type==='aftersale_approve'&&a.creator===s.role)throw new Error('申请与审核需要由不同角色完成');a.status=action.type==='aftersale_approve'?'approved':'rejected';
      }
      if(action.type==='aftersale_receive') {if(a.type!=='return'||a.status!=='approved')throw new Error('仅审核通过的退货单可验收入库');productOf(s,o.productId).stock+=a.qty;a.status='received';a.returnedAt=now();}
      if(action.type==='aftersale_complete') {
        requireApprover(s);if(a.status!==(a.type==='return'?'received':'approved'))throw new Error(a.type==='return'?'需先完成退货验收，且不能重复确认退款':'需先审核通过，且不能重复确认退款');
        const refunded=s.aftersales.filter(x=>x.orderId===o.id&&x.status==='completed').reduce((n,x)=>n+x.amount,0);if(refunded+a.amount>orderAmount(o))throw new Error('累计退款不能超过订单实付金额');a.status='completed';a.completedAt=now();
      }
      audit(s,action.type==='aftersale_complete'?'退款登记完成':action.type==='aftersale_receive'?'退货验收入库':action.type==='aftersale_approve'?'售后审核通过':'售后审核驳回',a.id,before,a.status);break;
    }
    case 'customer_update': {
      const c=s.customers.find(x=>x.id===action.id);if(!c)throw new Error('客户不存在');const before=JSON.stringify(c);
      if(action.note!==undefined){if(action.note.length>2000)throw new Error('客户备注不能超过 2000 字');c.note=action.note.trim();}
      if(action.tags!==undefined){if(action.tags.length>12||action.tags.some(t=>!t.trim()||t.length>30))throw new Error('客户标签最多 12 个，每个不超过 30 字');c.tags=[...new Set(action.tags.map(t=>t.trim()))];}
      if(action.tier!==undefined){if(!['普通客户','复购客户','高价值'].includes(action.tier))throw new Error('客户等级不正确');c.tier=action.tier;}
      audit(s,'更新客户档案',c.id,before,JSON.stringify(c));break;
    }
    case 'supplier_update': {
      const p=s.suppliers.find(x=>x.id===action.id);if(!p)throw new Error('供应商不存在');const before=JSON.stringify(p);if(action.leadDays!==undefined){integer(action.leadDays,1,90,'交期天数');p.leadDays=action.leadDays;}if(action.contact!==undefined){if(!action.contact.trim()||action.contact.length>60)throw new Error('联系人须为 1–60 字');p.contact=action.contact.trim();}audit(s,'更新供应商',p.id,before,JSON.stringify(p));break;
    }
    case 'rule_update': {
      requireApprover(s);const r=s.rules.find(x=>x.id===action.id);if(!r)throw new Error('规则不存在');const before=JSON.stringify(r);if(action.enabled!==undefined)r.enabled=action.enabled;if(action.threshold!==undefined){integer(action.threshold,1,90,'规则阈值');r.threshold=action.threshold;}audit(s,'更新自动化规则',r.id,before,JSON.stringify(r));break;
    }
    case 'run_rules': {
      if(action.id&&!s.rules.some(r=>r.id===action.id))throw new Error('规则不存在');let created=0;
      for(const r of s.rules.filter(r=>r.enabled&&(!action.id||r.id===action.id))) {
        r.runs++;r.lastRun=now();
        if(r.type==='price') for(const l of s.listings.filter(l=>l.listed&&(l.price-l.competitor)/l.price*100>=r.threshold)) {
          const p=productOf(s,l.productId);if(margin(p,l.competitor,l.fee)>=20&&!openTasks(s,'price',p.id,l.id)) {
            // Validate the unrounded threshold as the UI margin may be rounded to 20.0%.
            try {validatePrice(p,l,l.competitor);}catch {continue;}
            addTask(s,{type:'price',productId:p.id,listingId:l.id,title:`${p.name} · ${l.channel}调价`,before:l.price,after:l.competitor,version:l.version,cost:p.cost,shipping:p.shipping,fee:l.fee,reason:`竞品价差超过 ${r.threshold}%，贡献利润率 ${margin(p,l.competitor,l.fee)}%`},'system');created++;
          }
        }
        if(r.type==='stock') for(const p of s.products.filter(p=>coverage(s,p)<r.threshold&&suggestedQty(s,p)>0)) if(!openTasks(s,'purchase',p.id)) {addTask(s,{type:'purchase',productId:p.id,supplierId:p.supplierId,title:`${p.name} · 采购补货`,qty:suggestedQty(s,p),reason:`库存覆盖低于 ${r.threshold} 天`},'system');created++;}
        if(r.type==='listing') for(const l of s.listings.filter(l=>!l.listed)) if(!openTasks(s,'listing',l.productId,l.id)) {addTask(s,{type:'listing',productId:l.productId,listingId:l.id,title:`${productOf(s,l.productId).name} · ${l.channel}上架`,before:0,after:1,version:l.version,reason:'渠道覆盖检查生成上架申请'},'system');created++;}
      }
      audit(s,'运行自动化规则',action.id||'全部启用规则','待运行',`新增 ${created} 个审批任务`);break;
    }
    default: throw new Error('不支持的业务操作');
  }
  s.revision++;s.updatedAt=now();assertState(s);return s;
}

export type MetricFilters = { channel?: string; days?: number; category?: string };
export type Financials = { grossRevenue:number; revenue:number; netRevenue:number; refunds:number; cost:number; shipping:number; fees:number; contribution:number; margin:number; orderCount:number; pendingOrders:number; shippedOrders:number; shortageOrders:number; cancelledOrders:number; refundCount:number; refundRate:number };
function financials(s:State, orders:Order[]):Financials {
  const active=orders.filter(o=>o.status!=='cancelled'), ids=new Set(active.map(o=>o.id));
  const refunds=s.aftersales.filter(a=>a.status==='completed'&&ids.has(a.orderId));
  const grossRevenue=active.reduce((n,o)=>n+orderAmount(o),0),refundAmount=refunds.reduce((n,a)=>n+a.amount,0);
  const returnedCost=refunds.filter(a=>a.type==='return').reduce((n,a)=>n+(orders.find(o=>o.id===a.orderId)!.cost*a.qty),0);
  const cost=active.reduce((n,o)=>n+o.cost*o.qty,0)-returnedCost,shipping=active.reduce((n,o)=>n+o.shipping,0);
  // Sum refunds before rounding each order's fee reversal, avoiding 1-cent drift.
  const fees=active.reduce((n,o)=>{const originalFee=channelFee(orderAmount(o),o.fee),refunded=refunds.filter(a=>a.orderId===o.id).reduce((sum,a)=>sum+a.amount,0);return n+originalFee-Math.min(originalFee,channelFee(refunded,o.fee));},0);
  const revenue=grossRevenue-refundAmount,contribution=revenue-cost-shipping-fees;
  return {grossRevenue,revenue,netRevenue:revenue,refunds:refundAmount,cost,shipping,fees,contribution,margin:revenue?Math.round(contribution/revenue*1000)/10:0,orderCount:active.length,pendingOrders:orders.filter(o=>o.status==='pending').length,shippedOrders:orders.filter(o=>o.status==='shipped').length,shortageOrders:orders.filter(o=>o.status==='shortage').length,cancelledOrders:orders.filter(o=>o.status==='cancelled').length,refundCount:refunds.length,refundRate:active.length?Math.round(new Set(refunds.map(a=>a.orderId)).size/active.length*1000)/10:0};
}
export function metrics(s:State,filters:MetricFilters={}) {
  const latest=Math.max(...s.orders.map(o=>Date.parse(o.createdAt))),start=filters.days?latest-(filters.days*24*3600000):0;
  const products=s.products.filter(p=>!filters.category||filters.category==='全部品类'||p.category===filters.category), productIds=new Set(products.map(p=>p.id));
  const orders=s.orders.filter(o=>(!filters.channel||filters.channel==='全部渠道'||o.channel===filters.channel)&&productIds.has(o.productId)&&Date.parse(o.createdAt)>=start);
  const core=financials(s,orders);
  const byChannel=channels.map(channel=>({channel,...financials(s,orders.filter(o=>o.channel===channel))}));
  const byProduct=products.map(p=>({productId:p.id,name:p.name,...financials(s,orders.filter(o=>o.productId===p.id)),stock:p.stock,reserved:reserved(s,p),available:available(s,p),inTransit:inTransit(s,p),coverage:coverage(s,p)}));
  const dates=[...new Set(orders.map(o=>o.createdAt.slice(0,10)))].sort();
  const trend=dates.map(date=>({date,name:date.slice(5),...financials(s,orders.filter(o=>o.createdAt.slice(0,10)===date))}));
  return {...core,byChannel,byProduct,trend,stockValue:products.reduce((n,p)=>n+p.stock*p.cost,0),stockUnits:products.reduce((n,p)=>n+p.stock,0),reservedUnits:products.reduce((n,p)=>n+reserved(s,p),0),availableUnits:products.reduce((n,p)=>n+available(s,p),0),inTransitUnits:products.reduce((n,p)=>n+inTransit(s,p),0),lowStock:products.filter(p=>coverage(s,p)<7).length,pendingTasks:s.tasks.filter(t=>t.status==='pending').length,approvedTasks:s.tasks.filter(t=>t.status==='approved').length,activeAftersales:s.aftersales.filter(a=>!['completed','rejected'].includes(a.status)).length,automationRuns:s.rules.reduce((n,r)=>n+r.runs,0)};
}

/** Useful at the persistence boundary and in tests; does not mutate state. */
export function assertState(s:State):void {
  for(const p of s.products) {integer(p.stock,0,100000000,'实物库存');if(reserved(s,p)>p.stock)throw new Error(`库存不一致：${p.id} 的占用超过实物库存`);integer(p.cost,0,10000000,'商品成本');}
  for(const l of s.listings) {if(!s.products.some(p=>p.id===l.productId))throw new Error('渠道映射不存在');integer(l.price,1,10000000,'渠道价格');integer(l.fee,0,5000,'渠道费率');}
  for(const po of s.purchases){integer(po.received,0,po.qty,'累计入库数量');if((po.received===po.qty)!==(po.status==='received'))throw new Error('采购数量与状态不一致');}
  for(const o of s.orders) {integer(o.unitPrice,1,10000000,'订单成交单价');integer(o.qty,1,100000,'订单数量');const cases=s.aftersales.filter(a=>a.orderId===o.id&&a.status!=='rejected');if(cases.reduce((n,a)=>n+a.qty,0)>o.qty||cases.reduce((n,a)=>n+a.amount,0)>orderAmount(o))throw new Error('售后金额或数量超过原订单');}
}

