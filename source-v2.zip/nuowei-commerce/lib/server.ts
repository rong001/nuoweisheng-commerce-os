import {env} from 'cloudflare:workers';
import {seed,type State} from '@/lib/domain';
export function db(){if(!env.DB)throw new Error('数据库暂时不可用，请稍后重试');return env.DB;}
export async function loadSession(request:Request){const cookie=request.headers.get('cookie')||'';let id=cookie.match(/(?:^|;\s*)nw_demo=([a-f0-9-]{36})(?:;|$)/)?.[1];
 if(id){const row=await db().prepare('SELECT data, version FROM demo_sessions WHERE id = ?').bind(id).first<{data:string;version:number}>();if(row)return {id,state:JSON.parse(row.data) as State,version:row.version,fresh:false};}
 id=crypto.randomUUID();const state=seed();await db().prepare('INSERT INTO demo_sessions (id,data,version,updated_at) VALUES (?, ?, 1, ?)').bind(id,JSON.stringify(state),new Date().toISOString()).run();return {id,state,version:1,fresh:true};}
export function response(data:unknown,session:{id:string;fresh:boolean},request:Request,status=200){const headers:Record<string,string>={'Cache-Control':'no-store','Content-Type':'application/json'};if(session.fresh)headers['Set-Cookie']=`nw_demo=${session.id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${new URL(request.url).protocol==='https:'?'; Secure':''}`;return new Response(JSON.stringify(data),{status,headers});}
export function checkOrigin(request:Request){const origin=request.headers.get('origin');if(origin&&new URL(origin).host!==new URL(request.url).host)throw new Error('请求来源不匹配');}
