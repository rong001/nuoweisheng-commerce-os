export type Role='operator'|'approver'|'viewer';
export type Product={id:string;name:string;spec:string;category:string;price:number;cost:number;shipping:number;fee:number;stock:number;reserved:number;inTransit:number;daily:number;competitor:number;channels:string[];listed:boolean;version:number};
export type Task={id:string;type:'price'|'replenish'|'listing';sku:string;title:string;before:number;after:number;status:'pending'|'approved'|'executed'|'rejected'|'failed'|'rolledback';creator:Role|'system';approver?:Role;created:string;reason:string;cost:number;productVersion:number;executedVersion?:number;error?:string};
export type Order={id:string;channel:string;sku:string;qty:number;amount:number;status:'待发货'|'已发货'|'缺货'|'已取消';time:string;tracking?:string};
export type Purchase={id:string;sku:string;qty:number;status:'在途'|'已入库'};
export type Log={id:string;time:string;actor:string;action:string;detail:string;task?:string};
export type State={role:Role;products:Product[];tasks:Task[];orders:Order[];purchases:Purchase[];logs:Log[];rules:{id:string;name:string;enabled:boolean;description:string;runs:number}[];sync:string;failNext:boolean};
export const channels=['天猫','京东','拼多多','美团','私域'];
export const roleNames:Record<Role|'system',string>={system:'自动化规则',operator:'运营专员',approver:'业务负责人',viewer:'只读观察员'};
export const money=(v:number)=>new Intl.NumberFormat('zh-CN',{style:'currency',currency:'CNY',maximumFractionDigits:2}).format(v);
export const margin=(p:Product,price=p.price)=>Math.round((price-p.cost-p.shipping-price*p.fee)/price*1000)/10;
export const available=(p:Product)=>p.stock-p.reserved;
export const replenish=(p:Product)=>Math.max(0,Math.ceil(p.daily*10-available(p)-p.inTransit));
const now=()=>new Date().toISOString();
function log(s:State,action:string,detail:string,task?:string){s.logs.unshift({id:crypto.randomUUID(),time:now(),actor:roleNames[s.role],action,detail,task});s.logs=s.logs.slice(0,200)}
export function seed():State{
 const rows=[['NW-1001','家庭护理组合装','6 件 / 盒','家庭护理',129,78,50,12,8,119],['NW-1002','一次性防护口罩','50 只 / 盒','日常防护',39.9,16,180,32,45,36.9],['NW-1003','便携清洁湿巾','10 包 / 组','清洁用品',29.9,9.5,820,68,52,28.9],['NW-1004','一次性护理手套','100 只 / 盒','日常防护',49,22,420,24,22,46],['NW-1005','旅行收纳护理包','1 套 / 袋','家庭护理',69,29,236,18,16,65],['NW-1006','柔棉洁面巾','3 包 / 组','清洁用品',35,12,680,40,36,33.9],['NW-1007','日常清洁棉片','80 片 / 盒','清洁用品',19.9,5.8,620,28,31,18.9],['NW-1008','便携防护套装','3 件 / 套','日常防护',59,23,360,0,18,55]];
 const products:Product[]=rows.map((r,i)=>({id:String(r[0]),name:String(r[1]),spec:String(r[2]),category:String(r[3]),price:Number(r[4]),cost:Number(r[5]),stock:Number(r[6]),reserved:Number(r[7]),daily:Number(r[8]),competitor:Number(r[9]),shipping:i===0?6:3,fee:.08,inTransit:0,channels:i===7?[]:[...channels],listed:i!==7,version:1}));
 const orders:Order[]=Array.from({length:24},(_,i)=>{const p=products[i%7];return {id:'NW260926'+String(i+1).padStart(4,'0'),channel:channels[i%5],sku:p.id,qty:i===0?5:i===7?7:i===14?45:i%3+1,amount:Math.round(p.price*(i===0?5:i===7?7:i===14?45:i%3+1)*100)/100,status:i===14?'缺货':i<14?'待发货':'已发货',time:'2026-09-26 '+String(14-Math.floor(i/6)).padStart(2,'0')+':'+String(52-i%6*7).padStart(2,'0')}});
 const s:State={role:'operator',products,tasks:[],orders,purchases:[],logs:[],sync:now(),failNext:false,rules:[{id:'price',name:'竞品价格巡检',enabled:true,description:'发现价差 → 校验贡献利润率 ≥ 20% → 提交人工审批',runs:12},{id:'stock',name:'库存覆盖预警',enabled:true,description:'可售覆盖 < 7 天 → 按交期 7 天 + 安全库存 3 天生成建议',runs:24},{id:'sync',name:'多渠道数据对齐',enabled:true,description:'检查统一 SKU 映射与订单状态 → 记录同步批次',runs:48}]};
 log(s,'演示空间已创建','合成商品、订单与渠道快照已载入，渠道连接器为模拟模式。');return s;
}
function mustWrite(s:State){if(s.role==='viewer')throw new Error('当前为只读观察员，不能修改业务数据。')}
function requireApprover(s:State){if(s.role!=='approver')throw new Error('只有业务负责人可以审批、执行和回滚；请切换演示角色。')}
function addTask(s:State,p:Product,type:Task['type'],after:number,reason:string){
 if(s.tasks.some(t=>t.sku===p.id&&t.type===type&&['pending','approved','failed'].includes(t.status)))throw new Error('该商品已有同类未完成任务，请先处理现有任务。');
 if(s.tasks.length>=100)throw new Error('演示任务已满，请重置演示空间。');
 const t:Task={id:'TASK-'+crypto.randomUUID().slice(0,8).toUpperCase(),type,sku:p.id,title:type==='price'?p.name+' · 京东调价':type==='replenish'?p.name+' · 补货':p.name+' · 全渠道上架',before:type==='price'?p.price:type==='listing'?Number(p.listed):p.inTransit,after,status:'pending',creator:s.role,created:now(),reason,cost:p.cost,productVersion:p.version};s.tasks.unshift(t);log(s,'提交审批',t.title+'；'+reason,t.id);return t;
}
function validPrice(p:Product,price:number){if(!Number.isFinite(price)||price<.01||price>100000)throw new Error('售价必须在 ¥0.01 到 ¥100,000 之间。');if((price-p.cost-p.shipping-price*p.fee)/price<.2-1e-9)throw new Error('贡献利润率低于 20% 硬底线，不能提交或执行。最低建议售价 '+money((p.cost+p.shipping)/(.92-.2))+'。');}
export function act(original:State,input:Record<string,unknown>):{state:State;message:string}{
 const s=structuredClone(original);const type=String(input.type||'');let message='操作已完成';
 if(type==='role'){if(!['operator','approver','viewer'].includes(String(input.role)))throw new Error('无效角色');s.role=input.role as Role;log(s,'切换演示角色',roleNames[s.role]+'；此为沙盒角色演示，不是生产身份认证。');return {state:s,message:'已切换为'+roleNames[s.role]};}
 mustWrite(s);
 const p=s.products.find(p=>p.id===input.sku);const t=s.tasks.find(t=>t.id===input.id);
 switch(type){
 case 'propose_price':{if(!p)throw new Error('商品不存在');const price=Math.round(Number(input.price)*100)/100;validPrice(p,price);if(price===p.price)throw new Error('建议价格与当前价格相同');addTask(s,p,'price',price,'竞品快照 '+money(p.competitor)+'；贡献利润率 '+margin(p,price)+'%；人工审批后执行。');message='调价建议已提交，当前售价保持不变';break;}
 case 'propose_replenish':{if(!p)throw new Error('商品不存在');const qty=Number(input.qty??replenish(p));if(!Number.isInteger(qty)||qty<1||qty>10000)throw new Error('补货量须为 1–10,000 的整数');addTask(s,p,'replenish',qty,'可售 '+available(p)+' 件，日均 '+p.daily+' 件；交期 7 天、安全库存 3 天。');message='补货申请已提交审批';break;}
 case 'propose_listing':{if(!p||p.listed)throw new Error('请选择未上架商品');const content=String(input.content||'').trim();if(content.length<10||content.length>1000)throw new Error('上架文案应为 10–1,000 字');if(/治疗|治愈|保证疗效|百分百|100%|根治|抗癌/.test(content))throw new Error('文案包含无法证实的功效宣称，请修改后提交。');addTask(s,p,'listing',1,'资料校验通过；文案草稿：'+content);message='上架草稿已提交人工审核';break;}
 case 'approve':case 'reject':{requireApprover(s);if(!t||t.status!=='pending')throw new Error('任务状态已变更，请刷新');if(t.creator===s.role)throw new Error('不能审批由当前演示角色发起的任务，请由运营专员提交');const product=s.products.find(p=>p.id===t.sku)!;if(type==='approve'&&t.type==='price'){validPrice(product,t.after);if(product.version!==t.productVersion||product.cost!==t.cost)throw new Error('商品价格或成本已变化，请驳回后重新生成方案');}t.status=type==='approve'?'approved':'rejected';t.approver=s.role;log(s,type==='approve'?'审批通过':'审批驳回',t.title,t.id);message=type==='approve'?'审批通过，等待模拟执行':'申请已驳回';break;}
 case 'execute':{requireApprover(s);if(!t||!['approved','failed'].includes(t.status))throw new Error('只可执行已批准任务，重复执行已被阻止');const product=s.products.find(p=>p.id===t.sku)!;
 if(t.type==='price'){validPrice(product,t.after);if(product.version!==t.productVersion||product.cost!==t.cost)throw new Error('价格版本发生冲突，禁止覆盖新版本；请驳回或重新提交');}
 if(s.failNext){s.failNext=false;t.status='failed';t.error='模拟京东连接器超时，未修改业务数据。可重试。';log(s,'执行失败',t.error,t.id);message=t.error;break;}
 if(t.type==='price'){product.price=t.after;product.version++;t.executedVersion=product.version;}
 if(t.type==='replenish'){product.inTransit+=t.after;s.purchases.unshift({id:'PO-'+t.id.slice(5),sku:product.id,qty:t.after,status:'在途'});}
 if(t.type==='listing'){product.listed=true;product.channels=[...channels];}
 t.status='executed';t.error=undefined;log(s,'模拟执行成功',t.title+(t.type==='price'?'；'+money(t.before)+' → '+money(t.after):t.type==='replenish'?'；在途 +'+t.after+'，可售库存不变':'；5 个渠道已模拟上架'),t.id);message='模拟执行成功，业务数据与审计记录已更新';break;}
 case 'rollback':{requireApprover(s);if(!t||t.status!=='executed'||t.type!=='price')throw new Error('仅已执行的调价任务支持回滚');const product=s.products.find(p=>p.id===t.sku)!;if(product.version!==t.executedVersion||product.price!==t.after)throw new Error('该价格已有后续版本，不能直接回滚覆盖');product.price=t.before;product.version++;t.status='rolledback';log(s,'价格已回滚',t.title+'；恢复 '+money(t.before),t.id);message='已恢复原价，回滚记录已保存';break;}
 case 'receive':{const po=s.purchases.find(x=>x.id===input.id);if(!po||po.status!=='在途')throw new Error('采购单不存在或已入库');const product=s.products.find(x=>x.id===po.sku)!;product.inTransit-=po.qty;product.stock+=po.qty;po.status='已入库';log(s,'采购入库',product.name+'；实物库存 +'+po.qty);message='已确认收货，可售库存已增加';break;}
 case 'ship':case 'cancel_order':case 'reserve':{const order=s.orders.find(x=>x.id===input.id);if(!order)throw new Error('订单不存在');const product=s.products.find(x=>x.id===order.sku)!;
 if(type==='reserve'){if(order.status!=='缺货')throw new Error('订单不需要重新占库');if(available(product)<order.qty)throw new Error('可售库存不足');product.reserved+=order.qty;order.status='待发货';}
 else{if(order.status!=='待发货')throw new Error('订单状态已变化，不能重复操作');if(product.reserved<order.qty||product.stock<order.qty)throw new Error('库存校验失败，请先处理库存异常');product.reserved-=order.qty;if(type==='ship'){product.stock-=order.qty;order.status='已发货';order.tracking='DEMO-'+order.id;}else order.status='已取消';}
 log(s,type==='ship'?'模拟发货':type==='reserve'?'重新占库':'订单取消',order.id+'；'+product.name+' × '+order.qty);message=type==='ship'?'已模拟发货并扣减实物与占用库存':type==='reserve'?'占库成功，订单可发货':'订单已取消，占用库存已释放';break;}
 case 'toggle_rule':{requireApprover(s);const rule=s.rules.find(r=>r.id===input.id);if(!rule)throw new Error('规则不存在');rule.enabled=Boolean(input.enabled);log(s,rule.enabled?'启用规则':'暂停规则',rule.name);break;}
 case 'run_rules':{let count=0;for(const rule of s.rules.filter(r=>r.enabled)){rule.runs++;if(rule.id==='price'){for(const product of s.products.filter(p=>p.listed&&p.competitor<p.price&&margin(p,p.competitor)>=20)){if(!s.tasks.some(t=>t.sku===product.id&&t.type==='price'&&['pending','approved','failed'].includes(t.status))){addTask(s,product,'price',product.competitor,'规则扫描发现竞品价差，利润率 '+margin(product,product.competitor)+'%；需人工审批').creator='system';count++;}}}if(rule.id==='stock'){for(const product of s.products.filter(p=>available(p)/p.daily<7&&replenish(p)>0)){if(!s.tasks.some(t=>t.sku===product.id&&t.type==='replenish'&&['pending','approved','failed'].includes(t.status))){addTask(s,product,'replenish',replenish(product),'规则扫描发现库存覆盖不足 7 天').creator='system';count++;}}}if(rule.id==='sync')s.sync=now();}log(s,'自动化巡检完成','新增 '+count+' 个审批任务；所有外部动作仍需审批。');message='巡检完成，新增 '+count+' 个待审批任务';break;}
 case 'sync':{s.sync=now();log(s,'模拟渠道同步','5 个渠道连接器返回演示快照，未连接真实店铺。');message='5 个模拟渠道已完成同步';break;}
 case 'fail_next':{requireApprover(s);s.failNext=Boolean(input.enabled);log(s,'故障演练',s.failNext?'下一次执行将模拟超时':'已取消超时注入');message=s.failNext?'已注入一次连接器超时，供失败重试演示':'已关闭故障注入';break;}
 case 'reset':{const n=seed();return{state:n,message:'已重置本浏览器的演示空间'};}
 default:throw new Error('不支持的操作');
 }
 return {state:s,message};
}
export function answer(s:State,question:string){
 const q=question.trim();if(!q||q.length>1000)throw new Error('问题应为 1–1,000 字');
 const p=s.products[0];let text='',sources:string[]=[];
 if(/治疗|治愈|吃|药|孕|疾病|癌|功效/.test(q)){text='当前知识库没有足以支持医疗或功效结论的资料，建议转交具备资质的人工人员。可提供商品规格、订单履约和已配置的售后流程，不生成治疗承诺。';sources=['KB-004 · 宣称审核规则 v1.0 · 不支持无证据功效宣称'];}
 else if(/客服|退货|售后|口罩|多久|物流/.test(q)){text='客服回复草稿：您好，我们可以先核对您的订单编号和商品情况，再由人工客服按适用售后规则处理。演示政策：未发货订单可申请取消；已发货订单转人工审核。具体承诺需以真实店铺政策为准。\n\n商品示例：一次性防护口罩，50 只/盒。当前没有已验证的产品资质与医疗功效信息，不能补充相关承诺。';sources=['KB-001 · 演示售后流程 v1.0 · 第 2 条','SKU NW-1002 · 演示商品规格'];}
 else if(/选品|机会|潜力|推荐商品/.test(q)){const rank=[...s.products].sort((a,b)=>(margin(b)*.65+b.daily*.35)-(margin(a)*.65+a.daily*.35)).slice(0,3);text='按贡献利润率（65%）与日均销量（35%）的演示评分，优先评估：\n'+rank.map((p,i)=>`${i+1}. ${p.name}：利润率 ${margin(p)}%，日均 ${p.daily} 件，可售 ${available(p)} 件。`).join('\n')+'\n建议先做小批量渠道验证；该评分未包含真实流量、广告成本和退货损失。';sources=['统一商品库 · 当前演示快照','SCORING-01 · 透明加权规则'];}
 else if(/库存|补货|缺货/.test(q)){const risks=s.products.filter(p=>available(p)/p.daily<7);text=risks.length?risks.map(p=>`${p.name}：可售 ${available(p)} 件，日均 ${p.daily} 件，覆盖 ${(available(p)/p.daily).toFixed(1)} 天；在途 ${p.inTransit} 件，建议补货 ${replenish(p)} 件。`).join('\n')+'\n计算：日均销量 ×（7 天交期 + 3 天安全库存）− 可售 − 在途。采购确认仅增加在途，收货后才增加可售。':'当前没有库存覆盖低于 7 天的商品。';sources=['库存账本 · 当前演示状态','RULE-STOCK · 7 天交期 / 3 天安全库存'];}
 else if(/调价|价格|利润|毛利|竞品/.test(q)){text=`${p.name}当前京东售价 ${money(p.price)}，演示竞品报价 ${money(p.competitor)}。跟价后贡献利润率为 ${margin(p,p.competitor)}%。\n计算：（售价 − 成本 ${money(p.cost)} − 运费 ${money(p.shipping)} − 售价 × 8% 渠道费）÷ 售价。\n硬底线为 20%。建议进入竞争情报页评估并提交审批，审批通过前不变更价格。`;sources=['SKU NW-1001 · 商品成本与价格快照','RULE-PRICE · 20% 贡献利润率底线'];}
 else if(/经营|销售|今天|分析|为什么|重点/.test(q)){text=`演示经营快照的主要待办：\n1. ${s.products.filter(p=>available(p)/p.daily<7).length} 个商品库存覆盖不足 7 天，先检查补货交期。\n2. ${s.tasks.filter(t=>t.status==='pending').length} 个任务待审批，价格和采购在批准前不会执行。\n3. ${s.orders.filter(o=>o.status==='待发货').length} 笔样例订单待发货，${s.orders.filter(o=>o.status==='缺货').length} 笔待处理库存异常。\n经营趋势采用合成快照；当前数据不能证明实际增长原因。`;sources=['统一订单与库存账本 · 当前状态','审批中心 · 当前任务'];}
 else{text='这个问题目前缺少可检索的演示资料，我不会编造结论。可以询问：哪些商品需要补货、护理组合装是否应该跟价、如何挑选潜力商品，或生成售后客服回复。';sources=['知识范围：商品 / 库存 / 订单 / 调价规则 / 演示售后政策'];}
 return {text,sources,engine:'规则驱动演示引擎 · 未接入外部大模型',created:now()};
}
