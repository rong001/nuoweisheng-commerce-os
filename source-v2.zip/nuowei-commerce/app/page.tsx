"use client";
import { useEffect, useState } from 'react';
import CommerceApp from '../commerce-app';
export default function Page() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  return ready ? <CommerceApp/> : <div style={{display:'grid',placeItems:'center',minHeight:'100vh',color:'#6859d9',fontFamily:'sans-serif'}}>正在打开商业运营中枢…</div>;
}
