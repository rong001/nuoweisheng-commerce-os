"use client";
import {type ReactNode} from "react";
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from "@/components/ui/select";
import {Table,TableHeader,TableBody,TableRow,TableHead,TableCell} from "@/components/ui/table";
export const tone=(s:string)=>s==='pending'||s==='缺货'?'orange':s==='failed'?'red':s==='executed'||s==='已发货'||s==='已入库'?'green':s==='rejected'||s==='rolledback'||s==='已取消'?'gray':'violet';
export const date=(s:string)=>new Date(s).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
export function Tag({children,color='violet'}:{children:ReactNode;color?:string}){return <span className={'tag '+color}>{children}</span>}
export function Pick({value,onChange,values,label}:{value:string;onChange:(v:string)=>void;values:string[];label:string}){return <Select value={value} onValueChange={onChange}><SelectTrigger aria-label={label}><SelectValue/></SelectTrigger><SelectContent>{values.map(v=><SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>}
export function DataTable({headers,children}:{headers:string[];children:ReactNode}){return <Table><TableHeader><TableRow>{headers.map(h=><TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader><TableBody>{children}</TableBody></Table>}
