import type { Metadata } from 'next';
import '../commerce.css';
export const metadata: Metadata = {
  title: '诺维生 Commerce OS · 商业运营中枢',
  description: '多渠道商品、订单、库存、经营决策与审批执行工作台。',
  icons: { icon: '/favicon-64.png', shortcut: '/favicon-64.png' },
};
export default function RootLayout({children}: Readonly<{children:React.ReactNode}>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
