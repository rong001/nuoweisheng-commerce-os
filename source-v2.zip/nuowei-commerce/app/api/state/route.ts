import {loadSession,response} from '@/lib/server';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{const s=await loadSession(request);return response({state:s.state,version:s.version},s,request);}catch(e){console.error(e);return Response.json({error:'演示数据库暂时不可用，请点击重试。'},{status:503});}}
