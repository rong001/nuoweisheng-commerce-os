import {loadSession,response,checkOrigin} from '@/lib/server';
import {answer} from '@/lib/domain';
export async function POST(request:Request){try{checkOrigin(request);const raw=await request.json();if(!raw||typeof raw!=="object"||Array.isArray(raw))throw new Error("无效请求格式");const input=raw as Record<string,unknown>;const s=await loadSession(request);return response(answer(s.state,String(input.question||'')),s,request);}catch(e){return Response.json({error:e instanceof Error?e.message:'分析暂不可用'},{status:400});}}
