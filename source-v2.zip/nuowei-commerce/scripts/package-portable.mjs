import { spawnSync } from "node:child_process";
import { copyFile, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { init, parse } from "es-module-lexer";

const projectRoot = fileURLToPath(new URL("..", import.meta.url));
const args = process.argv.slice(2);
const options = { out: "work/github-upload", archiveDir: "outputs", skipBuild: false, archives: false };

for (let index = 0; index < args.length; index += 1) {
  const arg = args[index];
  if (arg === "--out" || arg === "--archive-dir") {
    const value = args[++index];
    if (!value || value.startsWith("--")) throw new Error(`${arg} needs a directory.`);
    options[arg === "--out" ? "out" : "archiveDir"] = value;
  } else if (arg === "--skip-build") options.skipBuild = true;
  else if (arg === "--archives") options.archives = true;
  else if (arg === "--help") {
    console.log(`Build a single-file static application and optional release archives.

Usage: node scripts/package-portable.mjs [options]
  --out DIR          Portable HTML directory, relative to project root.
                     Default: work/github-upload
  --skip-build       Use the existing dist-pages build for inspection.
  --archives         Also create source and GitHub release ZIP archives.
                     Omit while source changes are still in progress.
  --archive-dir DIR  ZIP output directory, relative to project root.
                     Default: outputs

No repository creation, upload, login, or deployment is performed.`);
    process.exit(0);
  } else throw new Error(`Unknown option: ${arg}`);
}

const distDir = path.join(projectRoot, "dist-pages");
const outDir = path.resolve(projectRoot, options.out);
const archiveDir = path.resolve(projectRoot, options.archiveDir);

if (outDir === projectRoot || outDir === distDir) {
  throw new Error("Choose a portable output directory separate from the source and Vite build.");
}

if (!options.skipBuild) {
  const result = spawnSync(process.execPath, [
    path.join(projectRoot, "node_modules/vite/bin/vite.js"),
    "build", "--config", "vite.pages.config.ts",
  ], { cwd: projectRoot, stdio: "inherit" });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`Pages build failed (${result.status}).`);
}

function resolveBuiltAsset(url) {
  if (/^(?:[a-z]+:|\/\/)/i.test(url)) throw new Error(`External build asset: ${url}`);
  const absolute = path.resolve(distDir, url.replace(/^\.\//, ""));
  const relative = path.relative(distDir, absolute);
  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    throw new Error(`Build asset escaped dist-pages: ${url}`);
  }
  return absolute;
}

// HTML raw-text elements end on these sequences even when they occur inside a
// JavaScript/CSS string. Preserve the language-level slash while escaping HTML.
function escapeRawTextEndTag(source, tag) {
  return source.replace(new RegExp(`</${tag}`, "gi"), match => `<\\/${match.slice(2)}`);
}

let html = await readFile(path.join(distDir, "index.html"), "utf8");
const scripts = [...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*<\/script>/gi)];
const styles = [...html.matchAll(/<link\b(?=[^>]*\brel="stylesheet")[^>]*\bhref="([^"]+)"[^>]*\/?\s*>/gi)];
if (scripts.length !== 1) throw new Error(`Expected one bundled module, found ${scripts.length}.`);
if (styles.length !== 1) throw new Error(`Expected one bundled stylesheet, found ${styles.length}.`);

let javascript = await readFile(resolveBuiltAsset(scripts[0][1]), "utf8");
const css = await readFile(resolveBuiltAsset(styles[0][1]), "utf8");
const logo = await readFile(path.join(distDir, "brand-mark.png"));
const favicon = await readFile(path.join(distDir, "favicon-64.png"));
const logoUrl = `data:image/png;base64,${logo.toString("base64")}`;
const faviconUrl = `data:image/png;base64,${favicon.toString("base64")}`;

if (!javascript.includes("./brand-mark.png")) throw new Error("The expected brand image reference was not found.");
javascript = javascript.split("./brand-mark.png").join(logoUrl);
await init;
const [imports] = parse(javascript);
if (imports.some(entry => entry.d !== -2)) {
  throw new Error("The application still contains imports; bundle all modules before producing portable HTML.");
}
for (const match of css.matchAll(/url\(\s*["']?([^\s"')]+)["']?\s*\)/gi)) {
  if (!/^(?:data:|#)/i.test(match[1])) throw new Error(`Stylesheet needs an external asset: ${match[1]}`);
}

const inlineJs = escapeRawTextEndTag(javascript, "script");
const inlineCss = escapeRawTextEndTag(css, "style");
// Callback replacements are intentional: bundles may contain "$&" and other
// text that String.replace would otherwise interpret as replacement tokens.
html = html.replace(scripts[0][0], () => `<script type="module">\n${inlineJs}\n</script>`);
html = html.replace(styles[0][0], () => `<style>\n${inlineCss}\n</style>`);
html = html.replace(/<link\b(?=[^>]*\brel="icon")[^>]*>/gi,
  () => `<link rel="icon" type="image/png" href="${faviconUrl}" />`);

const embeddedJs = html.match(/<script type="module">\n([\s\S]*?)\n<\/script>/)?.[1];
const embeddedCss = html.match(/<style>\n([\s\S]*?)\n<\/style>/)?.[1];
if (embeddedJs !== inlineJs || embeddedCss !== inlineCss) throw new Error("HTML embedding changed or truncated the bundle.");
if (/<script\b[^>]*\bsrc=|<link\b[^>]*\brel="(?:stylesheet|modulepreload)"/i.test(html)) {
  throw new Error("Portable HTML still refers to external script or stylesheet resources.");
}
if (html.includes("./brand-mark.png") || html.includes("./favicon-64.png")) {
  throw new Error("Portable HTML still refers to a nonembedded image.");
}
const syntax = spawnSync(process.execPath, ["--check", "--input-type=module"], {
  input: embeddedJs, encoding: "utf8", maxBuffer: 5 * 1024 * 1024,
});
if (syntax.error) throw syntax.error;
if (syntax.status !== 0) throw new Error(`Embedded JavaScript failed syntax validation:\n${syntax.stderr}`);

const portableReadme = `# 诺维生 Commerce OS v2 — GitHub Pages 发布包

这是可交互的静态经营工作台，包含商品、订单、库存、采购、售后、AI 建议、审批与审计演示。
此文件夹是发布材料；生成打包文件本身不代表站点已经上线。

## 文件

- \`index.html\`：完整的单文件网站，已内联 JavaScript、CSS、品牌图片和 favicon，无需额外 CDN。
- \`favicon-64.png\`：可选的独立网站图标，页面本身已包含内嵌图标。
- \`README.md\`：发布和演示说明。
- 源码 ZIP（完整发布包中提供）：React/Vite 源码、锁定依赖清单，以及单独保留的原服务端工程。

## 通过 GitHub 网页发布

1. 登录 GitHub，创建一个公开仓库。
2. 通过 **Add file → Upload files** 将本目录的 \`index.html\`、\`favicon-64.png\` 和 \`README.md\` 上传至仓库根目录并提交。
3. 打开仓库 **Settings → Pages**，Source 选择 **Deploy from a branch**。
4. 选择实际提交的分支（通常为 \`main\`）和 **/ (root)**，保存。
5. 等待 Pages 发布完成，使用设置页提供的公开地址访问系统。

这里使用仓库根目录直接发布单文件 HTML，不需要运行源码仓库中的 Actions 构建工作流。
GitHub 仓库内直接点击 HTML 文件会显示源码；应使用 Pages 提供的网址打开网站。
单文件也可直接在现代浏览器打开；如浏览器限制本地文件存储，请使用 Pages 地址演示。

## 演示与数据边界

经营数据为合成演示数据，不代表该公司的真实内部经营情况。
渠道连接、调价、上架、采购、发货及 AI 建议为模拟或规则驱动流程，不会触达真实平台。
每个业务空间的操作保存在当前浏览器本地；不同浏览器不共享进度。
界面角色切换用于展示业务权限，没有服务端身份认证；不要输入真实个人信息或平台密钥。
此静态版与源码中保留的原 Vinext/Worker 服务端入口分开，GitHub Pages 不运行该后端。

## 重新生成

在解压后的源码根目录安装锁定依赖，然后执行：

    npm ci --include=dev --include=optional
    node scripts/package-portable.mjs

默认会重新构建并输出到 \`work/github-upload\`。要同时生成源码及发布 ZIP：

    node scripts/package-portable.mjs --archives

构建依赖已在 \`package-lock.json\` 中锁定；需要 Node.js 22.13 或更新版本。
源码包不包含依赖目录、Git 历史、运行数据、凭据或临时文件；原站点托管标识已替换为占位值。
`;

await mkdir(outDir, { recursive: true });
await writeFile(path.join(outDir, "index.html"), html, "utf8");
await copyFile(path.join(distDir, "favicon-64.png"), path.join(outDir, "favicon-64.png"));
await writeFile(path.join(outDir, "README.md"), portableReadme, "utf8");
console.log(`Portable HTML verified: ${path.join(outDir, "index.html")} (${Buffer.byteLength(html).toLocaleString()} bytes)`);

if (options.archives) {
  const { zipSync } = await import("fflate");
  const excludedDirectories = new Set([
    ".git", "node_modules", "dist", "dist-pages", ".next", ".vinext", ".wrangler",
    ".sites-runtime", ".agents", ".codex", ".cache", ".vercel", ".netlify", ".openai",
    ".ssh", ".aws", "outputs", "work", "coverage", "tmp", "temp", "tempfiles",
    "playwright-report", "test-results", "credentials", "secrets",
  ]);
  const supportedExtensions = new Set([
    ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json", ".css", ".scss",
    ".md", ".sql", ".svg", ".png", ".jpg", ".jpeg", ".webp", ".ico", ".yml",
    ".yaml", ".sh", ".txt", ".html", ".woff", ".woff2", ".ttf", ".license",
  ]);
  const sourceFiles = {};
  async function collect(directory, relative = "") {
    for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name, "en"))) {
      const absolute = path.join(directory, entry.name);
      const archiveName = path.posix.join(relative, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) {
        if (excludedDirectories.has(entry.name.toLowerCase()) || absolute === outDir || absolute === archiveDir) continue;
        await collect(absolute, archiveName);
      } else if (entry.isFile()) {
        if (/^(?:\.env(?:\.|$)|credentials?(?:\.|$)|secrets?(?:\.|$)|storage[-_]?state(?:\.|$))/i.test(entry.name)) continue;
        if (/(?:\.tsbuildinfo|\.log|\.zip|\.tmp|\.temp|\.bak|\.pem|\.key|\.p12|\.pfx|\.sqlite(?:3)?|\.db)$/i.test(entry.name)) continue;
        if (!supportedExtensions.has(path.extname(entry.name).toLowerCase()) && ![".gitignore", ".npmrc", "LICENSE"].includes(entry.name)) continue;
        const bytes = await readFile(absolute);
        if (entry.name === ".npmrc" && /(?:_authToken|_password|_auth)\s*=/i.test(bytes.toString("utf8"))) {
          throw new Error("Refusing to package an .npmrc containing authentication settings.");
        }
        sourceFiles[`nuowei-commerce/${archiveName}`] = bytes;
      }
    }
  }
  await collect(projectRoot);
  // Preserve the old server's configuration shape without distributing the
  // current hosted-project identity or other local tool metadata.
  sourceFiles["nuowei-commerce/.openai/hosting.json"] = Buffer.from(JSON.stringify({
    d1: "DB", r2: null, project_id: "REPLACE_WITH_YOUR_HOSTING_PROJECT_ID",
  }, null, 2) + "\n");
  const sourceName = "诺维生-Commerce-OS-v2-源码.zip";
  const releaseName = "诺维生-Commerce-OS-v2-GitHub发布包.zip";
  const sourceZip = zipSync(sourceFiles, { level: 6 });
  const releaseZip = zipSync({
    "index.html": Buffer.from(html),
    "favicon-64.png": favicon,
    "README.md": Buffer.from(portableReadme),
    [sourceName]: [sourceZip, { level: 0 }],
  }, { level: 6 });
  await mkdir(archiveDir, { recursive: true });
  await writeFile(path.join(archiveDir, sourceName), sourceZip);
  await writeFile(path.join(archiveDir, releaseName), releaseZip);
  console.log(`Source archive: ${path.join(archiveDir, sourceName)} (${Object.keys(sourceFiles).length} source files)`);
  console.log(`Release archive: ${path.join(archiveDir, releaseName)} (${releaseZip.length.toLocaleString()} bytes)`);
} else {
  console.log("Archive creation skipped. Pass --archives only after source changes are finalized.");
}
