import { createState, reduce, metrics, assertState, available, reserved, inTransit, suggestedQty, margin, priceFloor, money, orderAmount, channelFee, type Scenario, type State, type Action } from '../lib/commerce.ts';

let checks = 0;
const assert = (condition: unknown, message: string): void => { checks++; if (!condition) throw new Error(message); };
const equal = (actual: unknown, expected: unknown, message: string): void => assert(actual === expected, `${message}: expected ${String(expected)}, got ${String(actual)}`);
const throws = (run: () => unknown, message: string): void => { let threw = false; try { run(); } catch { threw = true; } assert(threw, message); };
const role = (s: State, value: State['role']) => reduce(s, { type: 'set_role', role: value });
const apply = (s: State, ...actions: Action[]): State => actions.reduce(reduce, s);

for (const scenario of ['daily', 'growth', 'profit'] as Scenario[]) {
  const s = createState(scenario), m = metrics(s);
  assertState(s);
  equal(s.products.length, scenario === 'growth' ? 32 : 24, `${scenario}: product count`);
  equal(s.orders.length, scenario === 'growth' ? 96 : scenario === 'profit' ? 64 : 48, `${scenario}: order count`);
  equal(s.listings.length, s.products.length * 5, `${scenario}: every SKU has five mappings`);
  assert(s.tasks.length > 0 && s.purchases.length > 0 && s.aftersales.length > 0 && s.logs.length > 0, `${scenario}: populated connected objects`);
  assert(s.orders.some(o => o.status === 'pending') && s.orders.some(o => o.status === 'shortage') && s.orders.some(o => o.status === 'shipped'), `${scenario}: order states represented`);
  equal(m.byChannel.reduce((n, c) => n + c.revenue, 0), m.revenue, `${scenario}: channel revenue reconciliation`);
  equal(m.byProduct.reduce((n, p) => n + p.contribution, 0), m.contribution, `${scenario}: product contribution reconciliation`);
  equal(m.trend.reduce((n, d) => n + d.grossRevenue, 0), m.grossRevenue, `${scenario}: chart reconciliation`);
  equal(m.revenue, m.grossRevenue - m.refunds, `${scenario}: net revenue formula`);
  equal(m.contribution, m.revenue - m.cost - m.shipping - m.fees, `${scenario}: contribution formula`);
  for (const p of s.products) {
    equal(reserved(s, p), s.orders.filter(o => o.productId === p.id && o.status === 'pending').reduce((n, o) => n + o.qty, 0), `${scenario}: derived reservations ${p.id}`);
    assert(available(s, p) >= 0, `${scenario}: no oversell ${p.id}`);
    assert(Number.isInteger(p.cost) && Number.isInteger(p.shipping), `${scenario}: integer product cents`);
  }
  assert(s.listings.every(l => Number.isInteger(l.price) && Number.isInteger(l.competitor) && Number.isInteger(l.fee)), `${scenario}: integer listing cents and fee basis points`);
  assert(s.orders.every(o => Number.isInteger(orderAmount(o))), `${scenario}: integer order amounts`);
}

// Reservation, cancellation, shipment and immutable snapshots.
{
  const initial = createState(), snapshot = JSON.stringify(initial), o = initial.orders.find(o => o.status === 'pending')!;
  const p = initial.products.find(p => p.id === o.productId)!, beforeAvailable = available(initial, p), beforeReserved = reserved(initial, p);
  const shipped = reduce(initial, { type: 'ship', id: o.id });
  equal(shipped.products.find(x => x.id === p.id)!.stock, p.stock - o.qty, 'shipment reduces physical stock');
  equal(reserved(shipped, p.id), beforeReserved - o.qty, 'shipment releases reservations');
  equal(available(shipped, p.id), beforeAvailable, 'shipment leaves unreserved availability unchanged');
  equal(JSON.stringify(initial), snapshot, 'reducer leaves original object untouched');
  throws(() => reduce(shipped, { type: 'ship', id: o.id }), 'double shipment blocked');
  const cancelled = reduce(initial, { type: 'cancel', id: o.id });
  equal(cancelled.products.find(x => x.id === p.id)!.stock, p.stock, 'cancellation does not consume physical stock');
  equal(available(cancelled, p.id), beforeAvailable + o.qty, 'cancellation releases reservations');
  equal(metrics(cancelled).grossRevenue, metrics(initial).grossRevenue - orderAmount(o), 'cancellation updates revenue');
  throws(() => reduce(cancelled, { type: 'cancel', id: o.id }), 'duplicate cancellation blocked');
  throws(() => reduce(initial, { type: 'ship', id: initial.orders.find(x => x.status === 'shortage')!.id }), 'shortage orders cannot ship');
}

// Purchasing increases in-transit only; receipt can be partial and enables allocation.
{
  let s = createState(), shortage = s.orders.find(o => o.status === 'shortage')!, p = s.products.find(p => p.id === shortage.productId)!;
  const beforeStock = p.stock, beforeTransit = inTransit(s, p);
  s = reduce(s, { type: 'suggest_purchase', productId: p.id, qty: 80 }); const id = s.tasks[0].id;
  throws(() => reduce(s, { type: 'suggest_purchase', productId: p.id, qty: 80 }), 'duplicate open purchase request blocked');
  throws(() => reduce(s, { type: 'execute', id }), 'operator cannot execute procurement');
  s = role(s, 'approver'); s = apply(s, { type: 'approve', id }, { type: 'execute', id });
  equal(s.products.find(x => x.id === p.id)!.stock, beforeStock, 'purchase execution does not increase physical stock');
  equal(inTransit(s, p.id), beforeTransit + 80, 'purchase execution increases transit');
  throws(() => reduce(s, { type: 'execute', id }), 'duplicate procurement execution blocked');
  const po = s.purchases.find(x => x.taskId === id)!;
  s = reduce(s, { type: 'receive', id: po.id, qty: 30 });
  equal(s.purchases.find(x => x.id === po.id)!.status, 'partial', 'partial receipt status');
  equal(s.products.find(x => x.id === p.id)!.stock, beforeStock + 30, 'partial receipt stock increase');
  equal(inTransit(s, p.id), beforeTransit + 50, 'partial receipt reduces transit');
  s = reduce(s, { type: 'reserve', id: shortage.id });
  equal(s.orders.find(x => x.id === shortage.id)!.status, 'pending', 'receipt enables shortage allocation');
  s = reduce(s, { type: 'ship', id: shortage.id });
  equal(s.orders.find(x => x.id === shortage.id)!.status, 'shipped', 'shortage-to-purchase-to-shipment completes');
  s = reduce(s, { type: 'receive', id: po.id });
  equal(s.purchases.find(x => x.id === po.id)!.status, 'received', 'remaining receipt completes purchase');
  throws(() => reduce(s, { type: 'receive', id: po.id }), 'duplicate completed receipt blocked');
  assertState(s);
}

// Price approvals, scope, immutable sales prices and version-safe rollback.
{
  let s = createState(), listing = s.listings.find(l => l.channel === '私域' && l.listed)!, p = s.products.find(p => p.id === listing.productId)!;
  const originalPrice = listing.price, oldOrderPrices = JSON.stringify(s.orders.map(o => o.unitPrice)), otherChannelPrice = s.listings.find(l => l.productId === p.id && l.id !== listing.id)!.price;
  throws(() => reduce(s, { type: 'suggest_price', listingId: listing.id, price: p.cost }), 'low margin blocked');
  throws(() => reduce(s, { type: 'suggest_price', listingId: listing.id, price: 2000.5 }), 'fractional cents blocked');
  s = reduce(s, { type: 'suggest_price', listingId: listing.id, price: listing.price + 250 }); const id = s.tasks[0].id;
  equal(s.listings.find(l => l.id === listing.id)!.price, originalPrice, 'proposal does not alter price');
  throws(() => reduce(s, { type: 'approve', id }), 'operator cannot approve');
  s = role(s, 'approver'); throws(() => reduce(s, { type: 'execute', id }), 'unapproved price cannot execute');
  s = apply(s, { type: 'approve', id }, { type: 'execute', id });
  equal(s.listings.find(l => l.id === listing.id)!.price, originalPrice + 250, 'approved channel price executes');
  equal(s.listings.find(l => l.productId === p.id && l.id !== listing.id)!.price, otherChannelPrice, 'other channels unaffected');
  equal(JSON.stringify(s.orders.map(o => o.unitPrice)), oldOrderPrices, 'historic order price snapshots unchanged');
  throws(() => reduce(s, { type: 'execute', id }), 'duplicate price execution blocked');
  s = reduce(s, { type: 'rollback', id }); equal(s.listings.find(l => l.id === listing.id)!.price, originalPrice, 'rollback restores original price');
  throws(() => reduce(s, { type: 'rollback', id }), 'duplicate rollback blocked');
  assert(margin(p, priceFloor(p, listing.fee), listing.fee) >= 20, 'computed floor satisfies displayed margin');
  const self = reduce(s, { type: 'suggest_price', listingId: listing.id, price: originalPrice + 200 });
  throws(() => reduce(self, { type: 'approve', id: self.tasks[0].id }), 'self approval blocked');
}

// Concurrent content and price tasks must not silently overwrite newer versions.
{
  let s = createState(), listing = s.listings.find(l => l.channel === '私域' && l.listed)!;
  s = reduce(s, { type: 'suggest_price', listingId: listing.id, price: listing.price + 100 }); const priceId = s.tasks[0].id;
  s = reduce(s, { type: 'suggest_content', listingId: listing.id, content: '家庭日常护理用品，包装规格清晰，请按说明使用与存放。' }); const contentId = s.tasks[0].id;
  s = role(s, 'approver'); s = apply(s, { type: 'approve', id: priceId }, { type: 'approve', id: contentId }, { type: 'execute', id: priceId });
  throws(() => reduce(s, { type: 'execute', id: contentId }), 'stale content task blocked');
  s = reduce(s, { type: 'reject', id: contentId }); equal(s.tasks.find(t => t.id === contentId)!.status, 'rejected', 'stale approved task can be closed');
  s = role(s, 'operator'); s = reduce(s, { type: 'suggest_price', listingId: listing.id, price: listing.price + 200 }); const nextId=s.tasks[0].id;
  s = role(s, 'approver'); s = apply(s, { type: 'approve', id: nextId }, { type: 'execute', id: nextId });
  throws(() => reduce(s, { type: 'rollback', id: priceId }), 'old price cannot roll back over a newer price version');
}

// Return approval -> receipt -> refund, including inventory and contribution impact.
{
  let s = createState(), o=s.orders.find(o=>o.status==='shipped'&&!s.aftersales.some(a=>a.orderId===o.id)&&o.qty>=2)!,p=s.products.find(p=>p.id===o.productId)!;
  const beforeStock=p.stock,before=metrics(s);
  s=reduce(s,{type:'aftersale_create',id:o.id,kind:'return',qty:1});const id=s.aftersales[0].id;
  equal(metrics(s).refunds,before.refunds,'pending refund not recognized');
  throws(()=>reduce(s,{type:'aftersale_receive',id}),'unapproved return cannot enter stock');
  throws(()=>reduce(s,{type:'aftersale_approve',id}),'operator cannot approve refund');
  s=role(s,'approver');s=reduce(s,{type:'aftersale_approve',id});
  throws(()=>reduce(s,{type:'aftersale_complete',id}),'return must be received before refund');
  s=reduce(s,{type:'aftersale_receive',id});equal(s.products.find(x=>x.id===p.id)!.stock,beforeStock+1,'return receipt restores stock exactly once');
  throws(()=>reduce(s,{type:'aftersale_receive',id}),'duplicate return receipt blocked');
  s=reduce(s,{type:'aftersale_complete',id});const after=metrics(s);
  equal(after.refunds,before.refunds+o.unitPrice,'completed refund amount recognized');
  equal(after.revenue,before.revenue-o.unitPrice,'completed refund reduces net revenue');
  equal(after.cost,before.cost-o.cost,'returned quantity reverses cost');
  equal(after.shipping,before.shipping,'original fulfillment expense retained');
  equal(after.fees,before.fees-channelFee(o.unitPrice,o.fee),'refunded sales reverse channel commission');
  throws(()=>reduce(s,{type:'aftersale_complete',id}),'duplicate refund blocked');
  throws(()=>reduce(s,{type:'aftersale_create',id:o.id,kind:'refund',qty:o.qty}),'over-return quantity blocked');
  assertState(s);
}

// Refund-only never adds stock or reverses product cost.
{
  let s=createState(),o=s.orders.find(o=>o.status==='shipped'&&!s.aftersales.some(a=>a.orderId===o.id))!,p=s.products.find(p=>p.id===o.productId)!,before=metrics(s);
  s=reduce(s,{type:'aftersale_create',id:o.id,kind:'refund',qty:1,amount:100});const id=s.aftersales[0].id;
  s=role(s,'approver');s=apply(s,{type:'aftersale_approve',id},{type:'aftersale_complete',id});
  equal(s.products.find(x=>x.id===p.id)!.stock,p.stock,'refund-only does not add inventory');equal(metrics(s).cost,before.cost,'refund-only does not reverse COGS');equal(metrics(s).revenue,before.revenue-100,'partial refund updates net revenue');
  throws(()=>reduce(s,{type:'aftersale_receive',id}),'refund-only cannot receive returns');
  throws(()=>reduce(s,{type:'aftersale_create',id:o.id,kind:'refund',qty:1,amount:o.unitPrice+1}),'refund above unit payment blocked');
}

// Listing/content actions, access controls and automatic rules.
{
  let s=createState(), l=s.listings.find(l=>!l.listed&&!s.tasks.some(t=>t.listingId===l.id))!;
  s=reduce(s,{type:'suggest_listing',listingId:l.id});const id=s.tasks[0].id;s=role(s,'approver');s=apply(s,{type:'approve',id},{type:'execute',id});
  equal(s.listings.find(x=>x.id===l.id)!.listed,true,'listing publishes selected channel');
  throws(()=>reduce(s,{type:'suggest_content',listingId:l.id,content:'本商品保证疗效，能够治愈各种疾病，请放心长期使用。'}),'unsupported efficacy claims blocked');
  s=role(s,'operator');s=reduce(s,{type:'suggest_content',listingId:l.id,content:'日常护理随心选择，独立包装便于收纳，请按照说明使用。'});const contentId=s.tasks[0].id;s=role(s,'approver');s=apply(s,{type:'approve',id:contentId},{type:'execute',id:contentId});
  assert(s.listings.find(x=>x.id===l.id)!.content!.includes('独立包装'),'approved content updates listing');
  const before=s.tasks.length;s=reduce(s,{type:'run_rules'});assert(s.tasks.length>=before,'automation creates actionable tasks');const after=s.tasks.length;s=reduce(s,{type:'run_rules'});equal(s.tasks.length,after,'repeated rules do not duplicate open tasks');
  s=reduce(s,{type:'rule_update',id:'RULE-STOCK',enabled:false});equal(s.rules.find(r=>r.id==='RULE-STOCK')!.enabled,false,'rule can pause');
  const p=s.products.find(p=>suggestedQty(s,p)>0)!;const old=suggestedQty(s,p);s=reduce(s,{type:'supplier_update',id:p.supplierId,leadDays:20});assert(suggestedQty(s,p)>old,'supplier lead time updates replenishment calculation');
  s=reduce(s,{type:'customer_update',id:s.customers[0].id,tags:['重点关注','重点关注'],note:'电话确认收货时段'});equal(s.customers[0].tags.length,1,'customer tags deduplicated');
  const viewer=role(s,'viewer');for(const action of [{type:'run_rules'},{type:'ship',id:s.orders.find(o=>o.status==='pending')!.id},{type:'rule_update',id:'RULE-PRICE',enabled:false},{type:'customer_update',id:s.customers[0].id,note:'blocked'}] as Action[])throws(()=>reduce(viewer,action),'viewer mutation blocked');
  assert(s.logs.length>createState().logs.length,'actions produce linked audit history');
}

// Tampered state and invalid numbers must not quietly corrupt the ledger.
{
  const s=createState(),bad=structuredClone(s),p=bad.products.find(p=>reserved(bad,p)>0)!;p.stock=0;
  throws(()=>assertState(bad),'corrupt reservation invariant detected');
  throws(()=>reduce(s,{type:'suggest_purchase',productId:s.products[0].id,qty:-2}),'negative purchase quantity blocked');
  throws(()=>reduce(s,{type:'receive',id:s.purchases[0].id,qty:1000000}),'over-receipt blocked');
  const channel=metrics(s,{channel:'天猫'});equal(channel.grossRevenue,metrics(s).byChannel.find(c=>c.channel==='天猫')!.grossRevenue,'channel filter uses canonical ledger');
  assert(!money(12345).includes('12345'),'money converts integer cents to currency');
}

console.log(`PASS: ${checks} assertions; 3 scenarios; inventory, procurement, price versions, approvals, refunds, finances, automation and permissions.`);
