import { createRoot } from "react-dom/client";
import CommerceApp from "../commerce-app";
import "../commerce.css";

const root = document.getElementById("root");

if (!root) {
  throw new Error("The Commerce OS application root is missing.");
}

createRoot(root).render(<CommerceApp />);
