# GitHub Pages 公开演示版

此入口将电商经营工作台打包成可在 GitHub Pages 访问的静态 React 应用。
入口为 `web/main.tsx`，加载根目录的 `commerce-app.tsx` 和 `commerce.css`。
Vite 配置为 `vite.pages.config.ts`，构建产物为 `dist-pages/index.html` 及其资源。

## 本地运行与构建

使用 Node.js 22.13 或更新版本。

```sh
npm ci --include=dev --include=optional
npm run dev:pages
npm run build:pages
npm run preview:pages
```

开发地址为 `http://127.0.0.1:4173`，构建预览地址为 `http://127.0.0.1:4174`。
`build:pages` 直接执行 Vite 构建；不执行整个旧应用的 TypeScript 检查，也不启动
Vinext、Cloudflare Worker 或数据库。运行时依赖只会从此静态入口引用的代码打包。

## 自动发布

1. 将项目根目录作为 GitHub 仓库根目录，提交源代码和 `package-lock.json`。
2. 在仓库 **Settings → Pages → Build and deployment** 中选择 **GitHub Actions**。
3. 推送到 `main`，或手动运行 **Deploy Commerce OS to GitHub Pages** 工作流。
4. 工作流安装锁定依赖、构建并上传 `dist-pages`，随后部署到 `github-pages` 环境。
   最终访问地址显示在该工作流的部署结果和仓库 Pages 设置中。

仓库默认分支若不是 `main`，需同步修改 `.github/workflows/pages.yml` 的触发分支。
Pages 首次启用及仓库环境保护规则属于仓库管理配置；工作流遵守这些设置。
当前目录新增工作流不代表已经创建远程仓库或完成发布。

Vite 使用相对资源路径 `base: './'`，支持 GitHub Pages 仓库子路径。
应用导航应采用 hash（如 `#/inventory`）或页内状态；不要依赖需要服务端回退的
`/inventory` 路径。公共图片使用 `./brand-mark.png` 或
`import.meta.env.BASE_URL + 'brand-mark.png'` 等相对资源路径，避免站点根路径。

工作流只上传构建目录，不上传源码、`.env`、本地运行数据或服务端文件。
任何导入浏览器入口的内容都会成为公开静态资源，因此不得在前端代码或
`VITE_*` 环境变量中放置密钥。公开源码仓库自身的可见范围由仓库设置决定。

## 公开演示的能力边界

- 经营数据为合成演示数据；公司需求判断来自职位描述的业务推演，不代表已核实的内部经营事实。
- 渠道连接、调价、上架、采购和履约均为模拟流程，不会改动任何真实电商平台或订单。
- 公开版状态保存在访问者自己的浏览器本地；每个演示场景使用独立状态，互不影响。
  不同设备或浏览器不共享状态，清理浏览器数据或重置场景会恢复演示初始数据。
- AI 建议的来源及运行模式以应用标识为准；规则或预设建议不得冒充实时模型调用。
- 静态版没有服务端鉴权。界面角色切换和审批权限用于演示流程，不能作为真实安全边界。
  不应录入真实客户、订单、员工信息、平台密钥或其他私密数据。
- 审计、幂等、库存与回滚能力在浏览器演示范围内呈现，不意味着已具备多用户并发、
  平台接入或生产级审计保障。

## 保留的服务端工程

原有 `app/`、API、数据库和 Vinext/Worker 源码单独保留，既有 `dev`、`build`、
`start` 脚本保持不变。它们不由 GitHub Pages 执行。
若后续接入真实业务，应单独部署后端服务，补齐服务端身份认证、角色权限、凭据管理、
真实渠道接口和持久化数据，再将静态前端连接至经授权的 API。

发布机制参考 [GitHub Pages 自定义工作流官方文档](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)。


